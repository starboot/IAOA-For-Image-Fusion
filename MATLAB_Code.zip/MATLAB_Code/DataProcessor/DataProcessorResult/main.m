clc;
close all;
clear;

% tempDataProcessorResult;

startNum = 1;
EndNum = 100;

for i = startNum : EndNum

    
    PATH = ['R' num2str(i) '.mat'];
    
    load (PATH)
    
    if i == 1
        
        tempDataProcessorResult = DataProcessorResult;
    end
    
    for j = 1 : 16
        
        if DataProcessorResult(j).tmpN > tempDataProcessorResult(j).tmpN
            tempDataProcessorResult(j) = DataProcessorResult(j);
        end
        
    end
    
    disp(['running: ' num2str(i/EndNum * 100) '%']);
    
end
DataProcessorResult = tempDataProcessorResult;
save ('DataProcessorResult', 'DataProcessorResult');
