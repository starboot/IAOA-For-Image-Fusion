
% �Ľ��������Ż��㷨���ڽ��������С����������
%
% 1������ѧ�������������Ż��㷨
% 2������ѧ��λ���������������Ż��㷨
% 3������ѧ�ԳƸ������������Ż��㷨
%       ��http://dictall.com/indu/402/4017167DCF0.htm
%       ��https://baike.baidu.com/item/%E5%AF%B9%E7%A7%B0%E7%AE%97%E5%AD%90/18898048?fr=aladdin
% -----------------------------����--------------------------------------
% N����Ⱥ��С
% M_Iter����������
% model����С������ģ�ͼ�����
% -----------------------------����--------------------------------------
% AOAsol�����Ž������
% AOAbest����Ӧ��ֵ����
% AOAmeanbest��ƽ����Ӧ��ֵ����
% [BestSol,AOAbest]=AOA(N, M_Iter, LB, UB, Dim, F_obj)
function [BestSol,AOAbest]=IAOA(N,M_Iter, LB, UB, Dim, F_obj)

Best_P=zeros(1,Dim);

Best_FF=inf;

AOAbest=zeros(M_Iter,1);

empty_particle.Position=[];

empty_particle.Cost=[];

particle=repmat(empty_particle, N, 1);

MOP_Max=0.9;

MOP_Min=0.2;

Alpha=5;

Mu=0.499;

nRepository = 40;

q = 0.5;

zeta = 1;

w = 1/(sqrt(2*pi)*q*N)*exp(-0.5*(((1:N)-1)/(q*N)).^2);

p = w/sum(w);

% Create New Population repository
repository = repmat(empty_particle, nRepository, 1);

for i=1:N
    
    particle(i).Position=unifrnd(LB, UB, [1 Dim]);
    
    particle(i).Cost=F_obj(particle(i).Position);
    
    if particle(i).Cost<Best_FF
        
        Best_FF=particle(i).Cost;
        
        Best_P=particle(i).Position;
        
    end
    
end

Xnew=particle;

Y = repmat(particle, N+nRepository,1);

for C_Iter=1:M_Iter
    
    MOP=1-((C_Iter)^(1/Alpha)/(M_Iter)^(1/Alpha));
    
    MOA=MOP_Min+C_Iter*((MOP_Max-MOP_Min)/M_Iter);
    
    sigma = zeros(N, Dim);
    
    for l = 1:N
        
        D = 0;
        
        for r = 1:N
            
            D = D + abs(particle(l).Position - particle(r).Position);
            
        end
        
        sigma(l, :) = zeta * D / (N-1);
        
    end
    
    for i=1:N
        
        for j=1:Dim
            
            r1=rand();
            
            if (size(LB,2)==1)
                
                if r1>MOA
                    
                    r2=rand();
                    
                    if r2>0.5
                        
                        Xnew(i).Position(j)=Best_P(1,j)/(MOP+eps)*(UB-LB)*Mu+LB;
                        
                    else
                        
                        Xnew(i).Position(j)=Best_P(1,j)*MOP*(UB-LB)*Mu+LB;
                        
                    end
                    
                else
                    
                    r3=rand();
                    
                    if r3>0.5
                        
                        Xnew(i).Position(j)=Best_P(1,j)-MOP*(UB-LB)*Mu+LB;
                        
                    else
                        
                        Xnew(i).Position(j)=Best_P(1,j)+MOP*(UB-LB)*Mu+LB;
                        
                    end
                    
                end
                
            end
            
            if (size(LB,2)~=1)
                
                r1=rand();
                
                if r1>MOA
                    
                    r2=rand();
                    
                    if r2>0.5
                        
                        Xnew(i).Position(j)=Best_P(1,j)/(MOP+eps)*((UB(j)-LB(j))*Mu+LB(j));
                        
                    else
                        
                        Xnew(i).Position(j)=Best_P(1,j)*MOP*((UB(j)-LB(j))*Mu+LB(j));
                        
                    end
                    
                else
                    
                    r3=rand();
                    
                    if r3>0.5
                        
                        Xnew(i).Position(j)=Best_P(1,j)-MOP*((UB(j)-LB(j))*Mu+LB(j));
                        
                    else
                        
                        Xnew(i).Position(j)=Best_P(1,j)+MOP*((UB(j)-LB(j))*Mu+LB(j));
                        
                    end
                    
                end
                
            end
            
        end
        
        Xnew(i).Position = limitToPosition(Xnew(i).Position,LB,UB);
        
        Xnew(i).Cost = F_obj(Xnew(i).Position);
        
        OBL_Position = UB + LB - Xnew(i).Position;
        
        OBL_Cost = F_obj(OBL_Position);
        
        if OBL_Cost < Xnew(i).Cost
            
            Xnew(i).Position = OBL_Position;
            
            Xnew(i).Cost = OBL_Cost;
        end
        
        if Xnew(i).Cost<particle(i).Cost
            
            particle(i).Position = Xnew(i).Position;
            
            particle(i).Cost = Xnew(i).Cost;
            
        end
        
        Y(i).Position=particle(i).Position;
        
        Y(i).Cost=particle(i).Cost;
        
        if particle(i).Cost<Best_FF
            
            Best_FF=particle(i).Cost;
            
            Best_P=particle(i).Position;
            
        end
        
    end
    
    for t = 1:nRepository
        
        repository(t).Position = zeros([1 Dim]);
        
        for i = 1:Dim
            
            l = RouletteWheelSelection(p);
            
            repository(t).Position(i)=particle(l).Position(i)+sigma(l, i)*randn;
            
        end
        
        repository(t).Cost = F_obj(repository(t).Position(:));
        
    end
    
    Y = [Y
        repository];
    
    [~, index]=sort([Y.Cost]);
    
    Y = Y(index);
    
    Y = Y(1:N);
    
    if Y(1).Cost < Best_FF
        
        Best_FF=Y(1).Cost;
        
        Best_P=Y(1).Position;
        
    end
    
    particle = Y;
    
    AOAbest(C_Iter)=Best_FF;
    
    if C_Iter == floor(M_Iter/5)
        
        BestSol.subPosition = Best_P;
        
        BestSol.subCost = AOAbest(C_Iter);
        
    end
    
end

BestSol.Position = Best_P;

BestSol.Cost = Best_FF;

end

function j = RouletteWheelSelection(P)

r = rand;

C = cumsum(P);

j = find(r <= C, 1, 'first');

end
