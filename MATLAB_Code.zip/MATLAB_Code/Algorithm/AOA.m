%
% Copyright (c) 2015, Mostapha Kalami Heris & Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "LICENSE" file for license terms.
%
% Project Code: YPEA104
% Project Title: Ant Colony Optimization for Continuous Domains (ACOR)
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Cite as:
% Mostapha Kalami Heris, ACO for Continuous Domains in MATLAB (URL: https://yarpiz.com/67/ypea104-acor), Yarpiz, 2015.
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
%

function [BestSol,AOAbest]=AOA(N, M_Iter, LB, UB, Dim, F_obj)

Best_P=zeros(1,Dim);
Best_FF=inf;
AOAbest=zeros(M_Iter,1);

%Initialize the positions of solution
empty_particle.Position=[];
empty_particle.Cost=[];

particle=repmat(empty_particle,N,1);

MOP_Max=0.9;
MOP_Min=0.2;
C_Iter=1;
Alpha=5;
Mu=0.499;

for i=1:N
    % Initialize Position
    particle(i).Position=rand(1,Dim).*(UB-LB)+LB;
    % Evaluation
    particle(i).Cost=F_obj(particle(i).Position);  %Calculate the fitness values of solutions
    
    if particle(i).Cost<Best_FF
        Best_FF=particle(i).Cost;
        Best_P=particle(i).Position;
    end
end
Xnew=particle;

while C_Iter<M_Iter+1  %Main loop
    MOP=1-((C_Iter)^(1/Alpha)/(M_Iter)^(1/Alpha));   % Probability Ratio 
    MOA=MOP_Min+C_Iter*((MOP_Max-MOP_Min)/M_Iter); %Accelerated function
   
    %Update the Position of solutions
    for i=1:N   % if each of the UB and LB has a just value 
        for j=1:Dim
           r1=rand();
            if (size(LB,2)==1)
                if r1>MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i).Position(j)=Best_P(1,j)/(MOP+eps)*((UB-LB)*Mu+LB);
                    else
                        Xnew(i).Position(j)=Best_P(1,j)*MOP*((UB-LB)*Mu+LB);
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i).Position(j)=Best_P(1,j)-MOP*((UB-LB)*Mu+LB);
                    else
                        Xnew(i).Position(j)=Best_P(1,j)+MOP*((UB-LB)*Mu+LB);
                    end
                end               
            end
            
            
            if (size(LB,2)~=1)   % if each of the UB and LB has more than one value 
                r1=rand();
                if r1>MOA
                    r2=rand();
                    if r2>0.5
                        if rand()>0.5
                            Xnew(i).Position(j)=Best_P(1,j)/(MOP+eps)*((UB(j)-LB(j))*Mu+LB(j));
                        else
                            Xnew(i).Position(j)=particle(i).Position(j)/(MOP+eps)*((UB(j)-LB(j))*Mu+LB(j));
                        end
                    else
                        if rand()>0.5
                            Xnew(i).Position(j)=Best_P(1,j)*MOP*((UB(j)-LB(j))*Mu+LB(j));
                        else
                            Xnew(i).Position(j)=particle(i).Position(j)*MOP*((UB(j)-LB(j))*Mu+LB(j));
                        end
                    end
                else
                    r3=rand();
                    if r3>0.5
                        if rand()>0.5
                            Xnew(i).Position(j)=Best_P(1,j)-MOP*((UB(j)-LB(j))*Mu+LB(j));
                        else
                            Xnew(i).Position(j)=particle(i).Position(j)-MOP*((UB(j)-LB(j))*Mu+LB(j));
                        end
                    else
                        if rand()>0.5
                            Xnew(i).Position(j)=Best_P(1,j)+MOP*((UB(j)-LB(j))*Mu+LB(j));
                        else
                            Xnew(i).Position(j)=particle(i).Position(j)+MOP*((UB(j)-LB(j))*Mu+LB(j));
                        end
                    end
                end               
            end
            
        end
        
        % �޽�
        Xnew(i).Position = limitToPosition(Xnew(i).Position,LB,UB);     
 
        Xnew(i).Cost=F_obj(Xnew(i).Position);  % calculate Fitness function 


        if Xnew(i).Cost<particle(i).Cost
            particle(i).Position=Xnew(i).Position;
            particle(i).Cost=Xnew(i).Cost;
        end

        if particle(i).Cost<Best_FF
            Best_FF=particle(i).Cost;
            Best_P=particle(i).Position;
        end
        
    end
    
    

    
    %Update the convergence curve
    AOAbest(C_Iter)=Best_FF;
    
    if C_Iter == floor(M_Iter/5)
        BestSol.subPosition = Best_P;
        BestSol.subCost = AOAbest(C_Iter);
    end
    
    C_Iter=C_Iter+1;  % incremental iteration
   
end
BestSol.Position = Best_P;
BestSol.Cost = Best_FF;
end



